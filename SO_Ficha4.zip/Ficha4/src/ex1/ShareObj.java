package ex1;

public class ShareObj {
    private int number;
    private String name;

    public int getNumber() {
        return number;
    }

    public void setNumber(int x) {
        this.number = x;
    }

    public String getName() {
        return name;
    }

    public void setName(String n) {
        this.name = n;
    }
}
