/* 
 * File:   main.c
 * Author: OAO
 */

#include <stdio.h>
#include <stdlib.h>

/*
 * Exercise 11
 */
int main(int argc, char** argv) {
    int num = 0;
    
    for (; num <= 20; num += 2) {
        printf("\n%d", num);        
    } 
   
    return 0;
}

