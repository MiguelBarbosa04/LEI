/* 
 * File:   utils.h
 * Author: OAO
 */

#ifndef UTILS_H
#define UTILS_H

int clean_buffer();

char lerChar();

int countChar(char, char * );

int lastIndex(char *, char );
        
int lerString(char *, int );


#endif /* UTILS_H */

