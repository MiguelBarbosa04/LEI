﻿# Exercícios de C
